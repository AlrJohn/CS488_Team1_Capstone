"""Tests for manual carton-placement tracker and history writer."""
import csv
import tempfile
import unittest
from pathlib import Path
import cv2
import numpy as np
from camera_inspection import CanBoxPlacement, Detection, load_settings
from history_store import save_box


class TestInspection(unittest.TestCase):
    def setUp(self):
        self.settings = load_settings()
        self.tracker = CanBoxPlacement(self.settings)
        self.rect = (205,96,582,432)

    def feed(self, color, positions, active=True):
        events = []
        for x, y in positions:
            events += self.tracker.update_tracks(
                [Detection(color,(x,y),(x-20,y-30,40,60),2500)],
                self.rect, active=active)
        return events

    def test_one_stable_placement_counted_once(self):
        positions = [(250,60)]*4 + [(250,90),(250,112),(250,140),(250,170)] + [(250,170)]*12
        events = self.feed('Red', positions)
        self.assertEqual(len([e for e in events if e['action']=='placed']), 1)
        self.assertEqual(self.tracker.counts['Red'], 1)

    def test_motion_over_box_without_stopping_does_not_count(self):
        positions = [(250,60)]*3 + [(250,y) for y in range(80,405,17)]
        self.feed('Green', positions)
        self.assertEqual(self.tracker.counts['Green'], 0)

    def test_starting_inside_box_is_not_automatically_placement(self):
        self.feed('Blue', [(300,200)]*20)
        self.assertEqual(self.tracker.counts['Blue'], 0)

    def test_removal_decrements(self):
        self.feed('Red', [(250,60)]*4 + [(250,112),(250,150),(250,180)] + [(250,180)]*12)
        self.assertEqual(self.tracker.counts['Red'],1)
        self.feed('Red', [(250,140),(250,115),(250,80),(250,60)] + [(250,60)]*8)
        self.assertEqual(self.tracker.counts['Red'],0)

    def test_paused_placement_is_ignored(self):
        self.feed('Red', [(250,60)]*4 + [(250,110),(250,160)] + [(250,160)]*12,active=False)
        self.feed('Red', [(250,160)]*15,active=True)
        self.assertEqual(self.tracker.counts['Red'],0)

    def test_reset(self):
        self.feed('Red', [(250,60)]*4 + [(250,110),(250,160)] + [(250,160)]*12)
        self.tracker.reset()
        self.assertEqual(sum(self.tracker.counts.values()),0)

    def test_hsv_detection(self):
        frame=np.zeros((480,640,3),dtype=np.uint8)
        cv2.rectangle(frame,(100,160),(160,320),(0,0,220),-1)
        cv2.rectangle(frame,(230,160),(290,320),(40,185,55),-1)
        cv2.rectangle(frame,(350,160),(410,320),(215,80,25),-1)
        found={d.color for d in self.tracker.detect(frame)}
        self.assertEqual(found,{'Red','Green','Blue'})


    def test_settings_define_box_roi(self):
        x1, y1, x2, y2 = self.settings['box_roi']
        self.assertLess(x1, x2)
        self.assertLess(y1, y2)

    def test_csv_save(self):
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/'inspection_history.csv'
            expect={'Red':4,'Green':4,'Blue':4}
            passed=save_box(path,'Standard Variety Pack',expect,expect)
            self.assertEqual(passed['Status'],'PASS')
            failed=save_box(path,'Standard Variety Pack',expect,{'Red':5,'Green':4,'Blue':3})
            self.assertEqual(failed['Status'],'FAIL')
            with path.open(newline='',encoding='utf-8') as file:
                self.assertEqual(len(list(csv.DictReader(file))),2)

if __name__=='__main__':
    unittest.main()
