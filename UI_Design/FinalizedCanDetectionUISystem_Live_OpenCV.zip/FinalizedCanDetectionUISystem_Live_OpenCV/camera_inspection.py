"""Experimental HSV-based can placement tracker for a manually filled carton.

A camera views the carton and an approach area. A can is counted only when
its colored region is tracked into the configured BOX ROI and remains stable.
This is NOT a trained instance-segmentation or a verified physical-placement
sensor. Occlusions, reflective labels and hands can produce missed/false counts.
"""
from dataclasses import dataclass
from pathlib import Path
import json
import cv2
import numpy as np

DEFAULT_SETTINGS = Path(__file__).resolve().parent / 'camera_settings.json'
BGR_COLORS = {'Red': (40, 45, 235), 'Green': (60, 210, 75), 'Blue': (225, 130, 55)}


def load_settings(path=DEFAULT_SETTINGS):
    with open(path, encoding='utf-8') as file:
        settings = json.load(file)
    roi = settings.get('box_roi')
    if not isinstance(roi, list) or len(roi) != 4:
        raise ValueError('box_roi must be [left, top, right, bottom]')
    x1, y1, x2, y2 = map(float, roi)
    if not (0 <= x1 < x2 <= 1 and 0 <= y1 < y2 <= 1):
        raise ValueError('box_roi values must be fractions from 0 to 1, left < right and top < bottom')
    return settings


@dataclass
class Detection:
    color: str
    center: tuple
    box: tuple
    area: float


@dataclass
class Track:
    ident: int
    color: str
    center: tuple
    seen_outside: bool = False
    inside_frames: int = 0
    stable_frames: int = 0
    outside_frames: int = 0
    missed: int = 0
    counted: bool = False
    ignored: bool = False
    seen: int = 1


class CanBoxPlacement:
    """Counts confirmed, stable entries into a box ROI, not line crossings."""
    def __init__(self, settings):
        self.settings = settings
        self.reset()

    def reset(self):
        self.tracks = {}
        self.next_id = 1
        self.counts = {'Red': 0, 'Green': 0, 'Blue': 0}

    def box_rect(self, frame):
        height, width = frame.shape[:2]
        x1, y1, x2, y2 = self.settings['box_roi']
        return (int(x1*width), int(y1*height), int(x2*width), int(y2*height))

    def _inside(self, center, rect):
        x1, y1, x2, y2 = rect
        margin = int(self.settings.get('box_inner_margin_pixels', 5))
        x, y = center
        return x1 + margin <= x <= x2 - margin and y1 + margin <= y <= y2 - margin

    def detect(self, frame):
        hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)
        height, width = frame.shape[:2]
        detections = []
        kernel = np.ones((5, 5), np.uint8)
        min_area = float(self.settings.get('minimum_color_area', 480)) * (width*height)/(640*480)
        for color, ranges in self.settings['hsv_ranges'].items():
            mask = np.zeros((height, width), dtype=np.uint8)
            for values in ranges:
                h0, h1, s0, s1, v0, v1 = values
                mask = cv2.bitwise_or(mask, cv2.inRange(
                    hsv, np.array([h0,s0,v0], dtype=np.uint8),
                    np.array([h1,s1,v1], dtype=np.uint8)))
            mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
            mask = cv2.morphologyEx(mask, cv2.MORPH_CLOSE, kernel)
            contours, _ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            for contour in contours:
                area = cv2.contourArea(contour)
                if area < min_area:
                    continue
                x, y, bw, bh = cv2.boundingRect(contour)
                if bw < 14 or bh < 22 or bw > width * .55 or bh > height * .95:
                    continue
                moment = cv2.moments(contour)
                if moment['m00'] <= 0:
                    continue
                center = (int(moment['m10']/moment['m00']), int(moment['m01']/moment['m00']))
                detections.append(Detection(color, center, (x,y,bw,bh), area))
        return detections

    def update_tracks(self, detections, box_rect, active=True):
        """Update positions; count after stable placement inside box.

        Only objects first seen outside the box can trigger a new placement.
        During pause, a newly placed can is intentionally ignored until it
        leaves and re-enters. A tracked removal through the ROI edge reverses
        its count; disappearing inside the box does not (may be occlusion).
        """
        for track in self.tracks.values():
            track.missed += 1
        candidates = []
        max_distance = float(self.settings.get('maximum_track_distance', 100))
        for idx, detection in enumerate(detections):
            for ident, track in self.tracks.items():
                if track.color != detection.color:
                    continue
                distance = float(np.hypot(track.center[0] - detection.center[0],
                                          track.center[1] - detection.center[1]))
                if distance <= max_distance:
                    candidates.append((distance, idx, ident))
        used_detections, used_tracks = set(), set()
        events = []
        for distance, idx, ident in sorted(candidates):
            if idx in used_detections or ident in used_tracks:
                continue
            used_detections.add(idx)
            used_tracks.add(ident)
            detection = detections[idx]
            track = self.tracks[ident]
            inside = self._inside(detection.center, box_rect)
            if inside:
                track.inside_frames += 1
                track.outside_frames = 0
                if distance <= float(self.settings.get('stable_motion_pixels', 5)):
                    track.stable_frames += 1
                else:
                    track.stable_frames = 0
                if not active and not track.counted:
                    track.ignored = True
                if (active and track.seen_outside and not track.ignored and not track.counted
                    and track.inside_frames >= int(self.settings.get('minimum_inside_frames', 8))
                    and track.stable_frames >= int(self.settings.get('minimum_stable_frames', 7))):
                    track.counted = True
                    self.counts[track.color] += 1
                    events.append({'action':'placed', 'color':track.color,
                                   'track_id':ident, 'count':self.counts[track.color]})
            else:
                track.seen_outside = True
                track.inside_frames = 0
                track.stable_frames = 0
                track.outside_frames += 1
                track.ignored = False
                if (active and track.counted and track.outside_frames >=
                    int(self.settings.get('minimum_removal_frames', 6))):
                    track.counted = False
                    self.counts[track.color] = max(0, self.counts[track.color] - 1)
                    events.append({'action':'removed', 'color':track.color,
                                   'track_id':ident, 'count':self.counts[track.color]})
            track.center = detection.center
            track.missed = 0
            track.seen += 1
        for idx, detection in enumerate(detections):
            if idx in used_detections:
                continue
            inside = self._inside(detection.center, box_rect)
            self.tracks[self.next_id] = Track(
                self.next_id, detection.color, detection.center,
                seen_outside=not inside, inside_frames=1 if inside else 0,
                ignored=inside and not active)
            self.next_id += 1
        for ident in list(self.tracks):
            if self.tracks[ident].missed > int(self.settings.get('maximum_missed_frames', 25)):
                del self.tracks[ident]
        return events

    def process(self, frame, active=True):
        rect = self.box_rect(frame)
        detections = self.detect(frame)
        events = self.update_tracks(detections, rect, active=active)
        overlay = frame.copy()
        x1, y1, x2, y2 = rect
        cv2.rectangle(overlay, (x1,y1), (x2,y2), (255,190,20), 3)
        for detection in detections:
            x, y, bw, bh = detection.box
            color = BGR_COLORS.get(detection.color, (255,255,255))
            cv2.rectangle(overlay, (x,y), (x+bw,y+bh), color, 2)
            cv2.putText(overlay, detection.color, (x, max(18,y-6)),
                        cv2.FONT_HERSHEY_SIMPLEX, .55, (255,255,255), 2)
        if not active:
            cv2.putText(overlay, 'PAUSED - NOT COUNTING', (12,32),
                        cv2.FONT_HERSHEY_SIMPLEX, .65, (0,180,255), 2)
        cv2.putText(overlay, f'PLACED: {sum(self.counts.values())} (PROVISIONAL)',
                    (12, overlay.shape[0]-14), cv2.FONT_HERSHEY_SIMPLEX, .56, (255,255,255), 2)
        return overlay, events, self.counts.copy()
