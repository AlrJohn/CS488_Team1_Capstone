import sys
import json
import argparse
from pathlib import Path
from PySide6.QtCore import QFile, QTimer, Qt
from PySide6.QtUiTools import QUiLoader
from PySide6.QtGui import QColor, QPainter, QPixmap, QImage
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QLabel, QCheckBox,
                               QMessageBox, QTableWidget, QTableWidgetItem, QVBoxLayout, QLineEdit, QHeaderView, QMainWindow, QStackedWidget, QGraphicsView, QGraphicsScene, QFrame)
from widget import InspectionHistory
from camera_worker import CameraWorker
from camera_inspection import load_settings
from history_store import save_box

BASE = Path(__file__).resolve().parent


class FittedPage(QGraphicsView):
    """Keep Designer coordinates intact; fit the entire page to the display."""
    def __init__(self, content):
        super().__init__()
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setBackgroundBrush(QColor('#05253e'))
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        self.scene_obj = QGraphicsScene(self)
        self.setScene(self.scene_obj)
        content.setFixedSize(800, 600)
        self.proxy = self.scene_obj.addWidget(content)
        self.content = content
        self.scene_obj.setSceneRect(0, 0, 800, 600)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.fitInView(self.scene_obj.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)


def arrange_home(content):
    """Center the original buttons on the 800 x 600 Designer canvas."""
    title = content.findChild(QLabel, 'label')
    subtitle = content.findChild(QLabel, 'label_2')
    if title:
        title.setGeometry(80, 65, 640, 58)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet('color:white; font-size:32px; font-weight:bold; background:transparent;')
    if subtitle:
        subtitle.setGeometry(80, 126, 640, 28)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet('color:#bdd1e0; font-size:15px; background:transparent;')
    for i, (button_name, caption_name) in enumerate((
        ('ProductionRunButton', 'label_3'),
        ('ConfigureButton', 'label_4'),
        ('InspectionButton', 'label_5'),
    )):
        y = 187 + i * 116
        button = content.findChild(QPushButton, button_name)
        caption = content.findChild(QLabel, caption_name)
        if button:
            button.setGeometry(175, y, 450, 94)
            button.setStyleSheet(button.styleSheet() + 'QPushButton { font-size: 24px; font-weight: bold; border-radius: 12px; padding-bottom: 18px; }')
        if caption:
            caption.setGeometry(190, y + 57, 420, 24)
            caption.setAlignment(Qt.AlignmentFlag.AlignCenter)
            caption.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
            caption.setStyleSheet('color:white; background:transparent; font-size:14px;')
            caption.raise_()


class HMI:
    def __init__(self, camera_source=None):
        self.camera_settings = load_settings()
        self.camera_source = camera_source if camera_source is not None else self.camera_settings["camera_source"]
        self.camera = None
        self.counts = {"Red": 0, "Green": 0, "Blue": 0}
        self.completed_packs = 0
        self.loader = QUiLoader()
        self.pages = {}
        self.views = {}
        self.designer_windows = {}
        self.window = QMainWindow()
        self.window.setWindowTitle('Can Inspection System')
        self.stack = QStackedWidget()
        self.window.setCentralWidget(self.stack)
        for key, filename in [('home', 'home.ui'), ('configure', 'configure.ui'),
                              ('recipes', 'recipeScreen.ui'), ('run', 'runScreen.ui')]:
            file = QFile(str(BASE / filename))
            if not file.open(QFile.ReadOnly):
                raise RuntimeError(f'Cannot open {filename}')
            designer_window = self.loader.load(file)
            file.close()
            if designer_window is None:
                raise RuntimeError(f'Cannot load {filename}: {self.loader.errorString()}')
            self.designer_windows[key] = designer_window
            content = designer_window.takeCentralWidget()
            if content is None:
                raise RuntimeError(f'{filename} has no central widget')
            content.setParent(None)
            self.pages[key] = content
            if key == 'home':
                arrange_home(content)
            view = FittedPage(content)
            self.views[key] = view
            self.stack.addWidget(view)
        self.history = InspectionHistory()
        self.history.setMinimumSize(0, 0)
        self.history.back_button.clicked.disconnect()
        self.history.back_button.clicked.connect(lambda: self.show('home'))
        self.stack.addWidget(self.history)
        self.config = {'Red': 4, 'Green': 4, 'Blue': 4}
        self.recipes = {'Standard Variety Pack': self.config.copy()}
        self.selected_recipe = 'Standard Variety Pack'
        self.running = False
        self.elapsed = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.tick)

        self.bind('home', 'ProductionRunButton', self.start_run)
        self.bind('home', 'ConfigureButton', lambda: self.show('recipes'))
        self.bind('home', 'InspectionButton', lambda: self.show('history'))

        for color in ('red', 'green', 'blue'):
            self.bind('configure', f'{color}PlusButton', lambda c=color: self.adjust(c, 1))
            self.bind('configure', f'{color}MinusButton', lambda c=color: self.adjust(c, -1))
            checkbox = self.find('configure', f'{color}Enabled', QCheckBox)
            if checkbox:
                checkbox.stateChanged.connect(self.update_total)
        self.bind('configure', 'cancelButton', lambda: self.show('recipes'))
        self.bind('configure', 'saveButton', self.save_config)
        self.bind('recipes', 'cancelButton', lambda: self.show('home'))
        self.bind('recipes', 'runButton', self.start_run)
        self.bind('recipes', 'createNewButton', lambda: self.show('configure'))
        self.bind('run', 'StopButton', self.stop_run)
        self.bind('run', 'PauseButton', self.pause_run)
        self.bind('run', 'WrongCanPopupButton', self.wrong_can)

        self.recipe_table = self.find('recipes', 'recipeTable', QTableWidget)
        if self.recipe_table:
            self.recipe_table.itemSelectionChanged.connect(self.select_recipe)
        self.add_back_button('configure', 'Back to Home', 'home')
        self.add_back_button('recipes', 'Back to Home', 'home')
        self.add_back_button('run', 'Back to Home', 'home')
        self.setup_camera_panel()
        self.update_total()
        self.load_can_images()
        self.populate_recipes()
        self.show('home')

    def find(self, page, name, kind=QWidget):
        return self.pages[page].findChild(kind, name)

    def bind(self, page, name, callback):
        button = self.find(page, name, QPushButton)
        if button:
            button.clicked.connect(lambda checked=False, action=callback: action())

    def add_back_button(self, page, title, destination):
        content = self.pages[page]
        button = QPushButton(title, content)
        button.setObjectName('navigationBackButton')
        button.setGeometry(625, 12, 163, 47)
        button.setStyleSheet('QPushButton {background:#526D86;color:white;border-radius:8px;font-size:14px;font-weight:bold;} QPushButton:hover {background:#6986A1;}')
        button.raise_()
        button.clicked.connect(lambda checked=False, target=destination: self.navigate_back(target))

    def navigate_back(self, destination):
        if self.current == 'run':
            if not self.confirm_discard_box():
                return
            self.stop_camera()
            self.timer.stop()
            self.running = False
        self.show(destination)

    def show(self, name):
        if name == 'history':
            self.history.load_history()
            destination = self.history
        else:
            if name == 'recipes':
                self.populate_recipes()
            if name == 'run':
                self.update_target()
            destination = self.views[name]
        self.current = name
        self.stack.setCurrentWidget(destination)
        if not self.window.isVisible():
            self.window.showFullScreen()

    def adjust(self, color, delta):
        label = self.find('configure', f'{color}QtyLabel', QLabel)
        if label:
            label.setText(str(max(0, int(label.text()) + delta)))
        self.update_total()

    def get_config(self):
        config = {}
        for color in ('red', 'green', 'blue'):
            label = self.find('configure', f'{color}QtyLabel', QLabel)
            enabled = self.find('configure', f'{color}Enabled', QCheckBox)
            config[color.capitalize()] = int(label.text()) if label and (enabled is None or enabled.isChecked()) else 0
        return config

    def update_total(self, *_):
        total = sum(self.get_config().values())
        label = self.find('configure', 'totalLabel', QLabel)
        if label:
            label.setText(f'Total Expected Cans: {total}')
    def load_can_images(self):

        red = self.find('configure', 'redCanImage', QLabel)
        green = self.find('configure', 'greenCanImage', QLabel)
        blue = self.find('configure', 'blueCanImage', QLabel)
        if red:
            red.setPixmap(QPixmap(str(BASE / "YardsRedCan.webp")))
            red.setScaledContents(True)
        if green:
            green.setPixmap(QPixmap(str(BASE / "YardsGreenCan.webp")))
            green.setScaledContents(True)
        if blue:
            blue.setPixmap(QPixmap(str(BASE / "YardsBlueCan.webp")))
            blue.setScaledContents(True)
    def save_config(self):
        config = self.get_config()
        if sum(config.values()) == 0:
            QMessageBox.warning(self.pages['configure'], 'Invalid Configuration', 'Enable at least one can type with a positive quantity.')
            return
        self.config = config
        name_field = self.find('configure', 'recipeNameInput', QLineEdit)
        name = name_field.text().strip() if name_field else ''
        if not name:
            name = f'Custom Recipe {len(self.recipes)}'
        if name in self.recipes:
            QMessageBox.warning(self.pages['configure'], 'Duplicate Recipe', 'Please choose a unique recipe name.')
            return
        self.recipes[name] = config.copy()
        with open(BASE / "config.json", "w") as file:
            json.dump(config, file, indent=4)
            QMessageBox.information(
                self.window,
                "Saved",
                "Configuration saved successfully."
            )
        self.selected_recipe = name
        if name_field:
            name_field.clear()
        self.show('recipes')

    def populate_recipes(self):
        if not self.recipe_table:
            return
        table = self.recipe_table
        table.blockSignals(True)
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(['Recipe', 'Red', 'Green', 'Blue'])
        table.setRowCount(len(self.recipes))
        selected_row = 0
        for row, (name, config) in enumerate(self.recipes.items()):
            for col, value in enumerate([name, config['Red'], config['Green'], config['Blue']]):
                table.setItem(row, col, QTableWidgetItem(str(value)))
            if name == self.selected_recipe:
                selected_row = row
        table.selectRow(selected_row)
        table.blockSignals(False)
        self.update_recipe_labels()

    def select_recipe(self):
        row = self.recipe_table.currentRow()
        if row >= 0 and self.recipe_table.item(row, 0):
            self.selected_recipe = self.recipe_table.item(row, 0).text()
            self.update_recipe_labels()

    def update_recipe_labels(self):
        config = self.recipes[self.selected_recipe]
        label = self.find('recipes', 'selectedRecipeLabel', QLabel)
        if label:
            label.setText(f'Selected Recipe: {self.selected_recipe}')
        breakdown = self.find('recipes', 'recipeBreakdownLabel', QLabel)
        if breakdown:
            breakdown.setText(f"Red: {config['Red']}  Green: {config['Green']}  Blue: {config['Blue']}")

    def update_target(self):
        label = self.find('run', 'TargetQuantityLabel', QLabel)
        if label:
            label.setText(f'Target Quantity: {sum(self.config.values())}')

    def setup_camera_panel(self):
        """Keep original Qt Designer page, but show an actual large camera feed."""
        page = self.pages['run']
        panel = self.find('run', 'ProductionPanel', QFrame)
        panel.setGeometry(18, 95, 764, 386)
        panel.setStyleSheet('QFrame#ProductionPanel {background:#163759; border-radius:12px;}')
        geometry = {
            'varietyTitle': (18, 8, 726, 35),
            'TargetQuantityLabel': (485, 50, 255, 30),
            'currentCount': (485, 87, 255, 30),
            'countLabel1': (485, 130, 255, 36),
            'countLabel2': (485, 173, 255, 36),
            'countLabel3': (485, 216, 255, 36),
            'StatusLabel': (480, 260, 268, 46),
            'RunTimerLabel': (485, 318, 260, 24),
            'PackCountLabel': (485, 351, 260, 24),
        }
        for name, rect in geometry.items():
            label = self.find('run', name, QLabel)
            if label:
                label.setGeometry(*rect)
        for name in ('countLabel1', 'countLabel2', 'countLabel3'):
            label = self.find('run', name, QLabel)
            label.setStyleSheet('font-size:22px; font-weight:bold; color:#FFFFFF;')
        self.preview = QLabel('CAMERA NOT STARTED', panel)
        self.preview.setObjectName('LiveCameraPreview')
        self.preview.setGeometry(16, 51, 451, 298)
        self.preview.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.preview.setStyleSheet('background:#071724; border:2px solid #487496; border-radius:8px; color:#cbd5e1; font-size:20px;')
        self.preview.show()
        self.camera_note = QLabel('LIVE OpenCV camera  |  Blue outline = box inspection area', panel)
        self.camera_note.setGeometry(16, 352, 451, 24)
        self.camera_note.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.camera_note.setStyleSheet('color:#D4DFEC; font-size:12px; background:transparent;')
        self.camera_note.show()
        pause = self.find('run', 'PauseButton', QPushButton)
        pause.setGeometry(25, 505, 190, 61)
        pause.setStyleSheet('QPushButton {background:#F57C00; color:white; border-radius:12px; font-size:22px; font-weight:bold;}')
        stop = self.find('run', 'StopButton', QPushButton)
        stop.setGeometry(545, 505, 190, 61)
        stop.setStyleSheet('QPushButton {background:#D32F2F; color:white; border-radius:12px; font-size:22px; font-weight:bold;}')
        self.finish_button = QPushButton('FINISH BOX', page)
        self.finish_button.setGeometry(277, 505, 210, 61)
        self.finish_button.setStyleSheet('QPushButton {background:#159447; color:white; border-radius:12px; font-size:22px; font-weight:bold;} QPushButton:hover {background:#20B455;}')
        self.finish_button.clicked.connect(self.finish_box)
        self.finish_button.show()
        self.refresh_counts()

    def refresh_counts(self):
        for color, name in [('Green','countLabel1'),('Red','countLabel2'),('Blue','countLabel3')]:
            label = self.find('run', name, QLabel)
            if label:
                label.setText(f'{color}: {self.counts[color]} / {self.config[color]}')
        total = sum(self.counts.values())
        label = self.find('run', 'currentCount', QLabel)
        if label:
            label.setText(f'Detected: {total} / {sum(self.config.values())}')
        label = self.find('run', 'PackCountLabel', QLabel)
        if label:
            label.setText(f'Boxes Passed: {self.completed_packs}')

    def start_run(self):
        self.stop_camera()
        self.config = self.recipes[self.selected_recipe].copy()
        self.counts = {'Red':0,'Green':0,'Blue':0}
        self.elapsed = 0
        self.running = True
        self.show('run')
        self.refresh_counts()
        self.timer.start(1000)
        self.set_run_status('STATUS: RUNNING', 'PAUSE')
        self.preview.setText('OPENING CAMERA...')
        self.camera = CameraWorker(self.camera_settings, source=self.camera_source)
        self.camera.frame_ready.connect(self.on_camera_frame)
        self.camera.camera_error.connect(self.on_camera_error)
        self.camera.start()

    def on_camera_frame(self, frame, events, counts):
        if self.current != 'run':
            return
        # Qt GUI updates happen only on the main thread.
        rgb = frame[:, :, ::-1].copy()
        h, w = rgb.shape[:2]
        image = QImage(rgb.data, w, h, rgb.strides[0], QImage.Format.Format_RGB888).copy()
        self.preview.setPixmap(QPixmap.fromImage(image).scaled(
            self.preview.size(), Qt.AspectRatioMode.KeepAspectRatio,
            Qt.TransformationMode.SmoothTransformation))
        if not self.running:
            return
        self.counts = counts.copy()
        self.refresh_counts()
        if any(self.counts[c] > self.config[c] for c in self.counts):
            self.set_run_status('EXTRA CAN - REVIEW', 'PAUSE')
        elif self.counts == self.config:
            self.set_run_status('COUNT MATCH - CHECK BOX', 'PAUSE')
        else:
            self.set_run_status('STATUS: RUNNING', 'PAUSE')

    def on_camera_error(self, message):
        self.timer.stop()
        self.running = False
        self.set_run_status('CAMERA ERROR', 'RESUME')
        self.preview.setText('CAMERA ERROR\n' + message)
        QMessageBox.warning(self.window, 'Camera Not Available',
                            message + '\n\nCheck the camera connection and privacy permissions, then restart Production Run.')

    def tick(self):
        self.elapsed += 1
        h, remainder = divmod(self.elapsed, 3600)
        m, s = divmod(remainder, 60)
        label = self.find('run', 'RunTimerLabel', QLabel)
        if label:
            label.setText(f'Run Time: {h:02}:{m:02}:{s:02}')

    def set_run_status(self, status_text, button_text):
        status = self.find('run', 'StatusLabel', QLabel)
        if status:
            status.setText(status_text)
            bg = '#D32F2F' if ('EXTRA' in status_text or 'ERROR' in status_text) else '#159447'
            status.setStyleSheet(f'background:{bg}; color:white; font-size:14px; font-weight:bold; border-radius:8px;')
        button = self.find('run', 'PauseButton', QPushButton)
        if button:
            button.setText(button_text)

    def pause_run(self):
        if self.camera is None or not self.camera.isRunning():
            QMessageBox.information(self.window, 'Camera', 'Camera is not running. Check the connection.')
            return
        self.running = not self.running
        self.camera.set_active(self.running)
        if self.running:
            self.timer.start(1000)
            self.set_run_status('STATUS: RUNNING', 'PAUSE')
        else:
            self.timer.stop()
            self.set_run_status('STATUS: PAUSED', 'RESUME')

    def finish_box(self):
        if self.camera is None or not self.camera.isRunning():
            QMessageBox.warning(self.window, 'No Camera', 'Camera must be running to record an inspected box.')
            return
        if sum(self.counts.values()) == 0:
            answer = QMessageBox.question(self.window,'No Cans Detected',
                'No can placements were detected in the box. Record this box as FAIL?',
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if answer != QMessageBox.StandardButton.Yes:
                return
        self.running = False
        self.camera.set_active(False)
        self.timer.stop()
        path = BASE / 'inspection_history.csv'
        try:
            record = save_box(path,self.selected_recipe,self.config,self.counts,
                              mode='LIVE-OPENCV-BOX-ROI-PROTOTYPE')
        except Exception as exc:
            QMessageBox.warning(self.window,'Save Failed',str(exc))
            return
        if record['Status'] == 'PASS':
            self.completed_packs += 1
            QMessageBox.information(self.window,'Count Match',
                'The detected color counts match the recipe. Check physical carton contents. Remove this carton and position an empty one before pressing OK.')
        else:
            QMessageBox.warning(self.window,'Inspection Mismatch',
                'The observed counts do not match the recipe. Check and correct the box. Position an empty carton before pressing OK to reset.')
        self.counts = {'Red':0,'Green':0,'Blue':0}
        self.camera.reset_box()
        self.camera.set_active(True)
        self.running = True
        self.timer.start(1000)
        self.set_run_status('STATUS: RUNNING', 'PAUSE')
        self.refresh_counts()

    def confirm_discard_box(self):
        if sum(self.counts.values()) == 0:
            return True
        answer = QMessageBox.question(self.window,'Discard Incomplete Box?',
            'Current counts have not been saved. Leave this screen and discard the incomplete box count?',
            QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        return answer == QMessageBox.StandardButton.Yes

    def stop_camera(self):
        if self.camera is not None:
            self.camera.stop()
            self.camera = None

    def stop_run(self):
        if not self.confirm_discard_box():
            return
        self.stop_camera()
        self.timer.stop()
        self.running = False
        self.elapsed = 0
        self.show('home')

    def wrong_can(self):
        QMessageBox.warning(self.pages['run'], 'Inspection Alert',
                            'Live camera counts are provisional. Confirm the box contents physically before accepting a pack.')

    def shutdown(self):
        self.stop_camera()
        self.timer.stop()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Can Inspection System for Raspberry Pi touchscreen')
    parser.add_argument('--camera', default=None, help='USB camera number (0, 1, ...) or picamera2')
    args = parser.parse_args()
    app = QApplication(sys.argv[:1])
    app.setQuitOnLastWindowClosed(False)
    hmi = HMI(camera_source=args.camera)
    app.aboutToQuit.connect(hmi.shutdown)
    sys.exit(app.exec())
