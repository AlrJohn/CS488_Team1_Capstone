"""Live USB/OpenCV or Raspberry Pi CSI camera worker for the Qt HMI.

There is deliberately no demo mode, video-file playback, or synthetic source.
The worker processes actual frames, and Qt signals keep GUI updates on the
main thread.
"""
import sys
import threading
import cv2
from PySide6.QtCore import QThread, Signal
from camera_inspection import CanBoxPlacement


class CameraWorker(QThread):
    frame_ready = Signal(object, object, object)  # BGR overlay, events, counts
    camera_error = Signal(str)

    def __init__(self, settings, source=0, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.source = source
        self._lock = threading.Lock()
        self._keep_running = True
        self._active = True
        self._reset_requested = False
        self._tracker = CanBoxPlacement(settings)

    def set_active(self, active):
        with self._lock:
            self._active = bool(active)

    def reset_box(self):
        with self._lock:
            self._reset_requested = True

    def stop(self):
        with self._lock:
            self._keep_running = False
        if self.isRunning():
            self.wait(3500)

    def _open_camera(self):
        source = self.source
        if isinstance(source, str) and source.lower() == 'picamera2':
            try:
                from picamera2 import Picamera2
            except ImportError as exc:
                raise RuntimeError(
                    'Picamera2 is unavailable. Install python3-picamera2 on the Pi, '
                    'or use --camera 0 for a USB camera.'
                ) from exc
            cam = Picamera2()
            cam.configure(cam.create_video_configuration(main={
                'size': (int(self.settings['frame_width']),
                         int(self.settings['frame_height'])),
                'format': 'RGB888',
            }))
            cam.start()
            return None, cam

        if isinstance(source, str) and source.isdecimal():
            source = int(source)
        if not isinstance(source, int) or source < 0:
            raise RuntimeError(
                'Only a LIVE camera is supported: --camera 0, --camera 1, '
                'or --camera picamera2 on Raspberry Pi. Video files and demos are disabled.'
            )

        # Try V4L2 on Linux, falling back to the default backend if necessary.
        # On macOS the default backend normally uses AVFoundation.
        backends = [cv2.CAP_V4L2, cv2.CAP_ANY] if sys.platform.startswith('linux') else [cv2.CAP_ANY]
        for backend in backends:
            cap = cv2.VideoCapture(source, backend)
            if cap.isOpened():
                cap.set(cv2.CAP_PROP_FRAME_WIDTH, int(self.settings['frame_width']))
                cap.set(cv2.CAP_PROP_FRAME_HEIGHT, int(self.settings['frame_height']))
                cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
                ok, first_frame = cap.read()
                if ok and first_frame is not None:
                    return cap, None
            cap.release()
        raise RuntimeError(
            f'Cannot open live camera {source}. Check the USB connection, '
            'camera permissions, and whether another application is using it. '
            'Try --camera 1 if another camera is connected.'
        )

    def run(self):
        cap = pi_cam = None
        try:
            cap, pi_cam = self._open_camera()
            while True:
                with self._lock:
                    if not self._keep_running:
                        break
                    active = self._active
                    reset = self._reset_requested
                    self._reset_requested = False
                if reset:
                    self._tracker.reset()
                if pi_cam is not None:
                    rgb = pi_cam.capture_array('main')
                    frame = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
                else:
                    ok, frame = cap.read()
                    if not ok or frame is None:
                        raise RuntimeError(
                            'The live camera stopped returning frames. '
                            'Check its cable, power, and permissions.'
                        )
                frame = cv2.resize(frame, (
                    int(self.settings['frame_width']),
                    int(self.settings['frame_height']),
                ))
                overlay, events, counts = self._tracker.process(frame, active=active)
                self.frame_ready.emit(overlay, events, counts)
        except Exception as exc:
            self.camera_error.emit(str(exc))
        finally:
            if cap is not None:
                cap.release()
            if pi_cam is not None:
                pi_cam.stop()
                pi_cam.close()
