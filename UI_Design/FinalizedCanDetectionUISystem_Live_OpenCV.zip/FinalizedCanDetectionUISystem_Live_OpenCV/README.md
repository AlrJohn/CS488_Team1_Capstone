# Yards Brewing Can Inspection HMI — LIVE OpenCV Camera

This project uses a **real, connected camera only**. There is **no demo video,
no synthetic cans, no video-file playback, and no virtual counting line**.
Your existing Home, Configure Batch, Recipe Selection, Production Run and
Inspection History screens are preserved.

## 1. Run on your Mac with a connected camera

Open Terminal, navigate to the extracted folder, then run:

```bash
~/qt-env/bin/python -m pip install PySide6 opencv-python numpy
~/qt-env/bin/python main.py --camera 0
```

Select **Production Run** on the Home screen. The live OpenCV camera feed
appears inside the HMI. If camera 0 is not the correct camera, close the app
and try `--camera 1`. The Mac may ask for permission to access the camera;
allow it in **System Settings > Privacy & Security > Camera**.

If you do not pass `--camera`, the program uses `camera_source` in
`camera_settings.json`, which defaults to 0.

## 2. Run on the Raspberry Pi 5 with an HMI touchscreen

The Pi must be running a desktop session and have the camera connected.
Use a Python environment with **PySide6**, **OpenCV** and **NumPy** installed.
For a USB/UVC camera:

```bash
python3 main.py --camera 0
```

For a supported Raspberry Pi CSI camera with Picamera2 installed:

```bash
python3 main.py --camera picamera2
```

If you use a virtual environment, replace `python3` with its Python path.
On Raspberry Pi OS, `python3-picamera2` is typically installed using apt.
The HMI opens full screen. No separate OpenCV camera window is launched.

## 3. What the live camera does

1. The operator selects a recipe, e.g. 4 Red + 4 Green + 4 Blue.
2. The operator presses **Production Run**; the live camera opens.
3. A worker manually places cans into a box under the camera.
4. OpenCV detects red/green/blue HSV regions and tracks their motion.
5. The software *provisionally* counts a can when its tracked region moves
   from outside the box ROI to inside and remains stable for several frames.
6. The HMI shows the live preview, color counts, total and recipe comparison.
7. **Finish Box** writes the counts to `inspection_history.csv`; the History
   screen shows the saved results.

The **blue rectangle** on the live image marks the *inside of the box*.
It is **not** a counting line. It must be calibrated to the real camera view.

## 4. Adjust the camera's box inspection area

Edit `camera_settings.json`:

```json
"box_roi": [0.32, 0.20, 0.91, 0.90]
```

Values are normalized fractions `[left, top, right, bottom]`. The camera
should show the interior of the box **and the approach area where the worker
brings the cans into view**. Restart the app after changing settings.

The HSV ranges, minimum colored area and stability thresholds are also
configurable. Test and tune these using the actual Yards cans, lighting,
working distance and camera angle.

## 5. Important limitations

**This is live OpenCV color tracking, not your team's trained Hailo model.**
The uploaded project did not include `vision/pi/run.py`, `Pipeline.process()`,
or the compiled Hailo model. Therefore, this version cannot use those yet.

A single 2D camera cannot prove a can was released into the box: a can held
above it may look placed; hands, overlap, reflections, or missed detections
can change the counts. The tracker also requires a can to be seen outside
then inside the configured ROI. Validate using real hand-counted cartons.

A displayed `COUNT MATCH` or saved `PASS` means **the provisional observed
counts matched the recipe**, not that the physical box contents were verified.
The operator should check the actual carton before approving it.

## 6. Tests

```bash
python3 -m unittest -v test_inspection
```

These tests check the placement tracker and CSV writer using in-memory test
inputs; they do **not** certify accuracy with a physical camera.
