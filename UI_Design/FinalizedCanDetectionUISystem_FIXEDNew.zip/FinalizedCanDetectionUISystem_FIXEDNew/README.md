# Can Inspection System — Navigation and display fix

This version uses one full-screen window and a stacked page controller. Each original Qt Designer `.ui` page is loaded into a scaled graphics view; the controls remain clickable, and the original geometry is preserved. The Home page controls are centered for a 10-inch display.

Navigation:
- Home > Production Run > Active Production Run
- Home > Configure Batch > Recipe Selection > Create New Recipe > Configuration > Save > Recipe Selection
- Recipe Selection > Run > Active Production Run
- Home > Inspection History > Inspection History
- Back to Home buttons return to Home.

On Mac, from the folder containing main.py:

    ~/qt-env/bin/python main.py

PySide6 is required. The camera pipeline is not connected. GUI behavior requires testing on the target touchscreen.
