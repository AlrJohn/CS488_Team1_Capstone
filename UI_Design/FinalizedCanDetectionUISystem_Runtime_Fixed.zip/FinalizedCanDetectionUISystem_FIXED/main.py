import sys
from pathlib import Path
from PySide6.QtCore import QFile, QTimer, Qt
from PySide6.QtUiTools import QUiLoader
from PySide6.QtGui import QColor, QPainter
from PySide6.QtWidgets import (QApplication, QWidget, QPushButton, QLabel, QCheckBox,
                               QMessageBox, QTableWidget, QTableWidgetItem, QVBoxLayout, QLineEdit, QHeaderView, QMainWindow, QStackedWidget, QGraphicsView, QGraphicsScene, QFrame)
from widget import InspectionHistory

BASE = Path(__file__).resolve().parent


class FittedPage(QGraphicsView):
    """Keep Designer coordinates intact; fit the entire page to the display."""
    def __init__(self, content):
        super().__init__()
        self.setFrameShape(QFrame.Shape.NoFrame)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setVerticalScrollBarPolicy(Qt.ScrollBarPolicy.ScrollBarAlwaysOff)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setBackgroundBrush(QColor('#05253e'))
        self.setRenderHint(QPainter.RenderHint.Antialiasing)
        self.setRenderHint(QPainter.RenderHint.TextAntialiasing)
        self.scene_obj = QGraphicsScene(self)
        self.setScene(self.scene_obj)
        content.setFixedSize(800, 600)
        self.proxy = self.scene_obj.addWidget(content)
        self.content = content
        self.scene_obj.setSceneRect(0, 0, 800, 600)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        self.fitInView(self.scene_obj.sceneRect(), Qt.AspectRatioMode.KeepAspectRatio)


def arrange_home(content):
    """Center the original buttons on the 800 x 600 Designer canvas."""
    title = content.findChild(QLabel, 'label')
    subtitle = content.findChild(QLabel, 'label_2')
    if title:
        title.setGeometry(80, 65, 640, 58)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet('color:white; font-size:32px; font-weight:bold; background:transparent;')
    if subtitle:
        subtitle.setGeometry(80, 126, 640, 28)
        subtitle.setAlignment(Qt.AlignmentFlag.AlignCenter)
        subtitle.setStyleSheet('color:#bdd1e0; font-size:15px; background:transparent;')
    for i, (button_name, caption_name) in enumerate((
        ('ProductionRunButton', 'label_3'),
        ('ConfigureButton', 'label_4'),
        ('InspectionButton', 'label_5'),
    )):
        y = 187 + i * 116
        button = content.findChild(QPushButton, button_name)
        caption = content.findChild(QLabel, caption_name)
        if button:
            button.setGeometry(175, y, 450, 94)
            button.setStyleSheet(button.styleSheet() + 'QPushButton { font-size: 24px; font-weight: bold; border-radius: 12px; padding-bottom: 18px; }')
        if caption:
            caption.setGeometry(190, y + 57, 420, 24)
            caption.setAlignment(Qt.AlignmentFlag.AlignCenter)
            caption.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
            caption.setStyleSheet('color:white; background:transparent; font-size:14px;')
            caption.raise_()


class HMI:
    def __init__(self):
        self.loader = QUiLoader()
        self.pages = {}
        self.views = {}
        self.designer_windows = {}
        self.window = QMainWindow()
        self.window.setWindowTitle('Can Inspection System')
        self.stack = QStackedWidget()
        self.window.setCentralWidget(self.stack)
        for key, filename in [('home', 'home.ui'), ('configure', 'configure.ui'),
                              ('recipes', 'recipeScreen.ui'), ('run', 'runScreen.ui')]:
            file = QFile(str(BASE / filename))
            if not file.open(QFile.ReadOnly):
                raise RuntimeError(f'Cannot open {filename}')
            designer_window = self.loader.load(file)
            file.close()
            if designer_window is None:
                raise RuntimeError(f'Cannot load {filename}: {self.loader.errorString()}')
            self.designer_windows[key] = designer_window
            content = designer_window.takeCentralWidget()
            if content is None:
                raise RuntimeError(f'{filename} has no central widget')
            content.setParent(None)
            self.pages[key] = content
            if key == 'home':
                arrange_home(content)
            view = FittedPage(content)
            self.views[key] = view
            self.stack.addWidget(view)
        self.history = InspectionHistory()
        self.history.setMinimumSize(0, 0)
        self.history.back_button.clicked.disconnect()
        self.history.back_button.clicked.connect(lambda: self.show('home'))
        self.stack.addWidget(self.history)
        self.config = {'Red': 4, 'Green': 4, 'Blue': 4}
        self.recipes = {'Standard Variety Pack': self.config.copy()}
        self.selected_recipe = 'Standard Variety Pack'
        self.running = False
        self.elapsed = 0
        self.timer = QTimer()
        self.timer.timeout.connect(self.tick)

        self.bind('home', 'ProductionRunButton', self.start_run)
        self.bind('home', 'ConfigureButton', lambda: self.show('recipes'))
        self.bind('home', 'InspectionButton', lambda: self.show('history'))

        for color in ('red', 'green', 'blue'):
            self.bind('configure', f'{color}PlusButton', lambda c=color: self.adjust(c, 1))
            self.bind('configure', f'{color}MinusButton', lambda c=color: self.adjust(c, -1))
            checkbox = self.find('configure', f'{color}Enabled', QCheckBox)
            if checkbox:
                checkbox.stateChanged.connect(self.update_total)
        self.bind('configure', 'cancelButton', lambda: self.show('recipes'))
        self.bind('configure', 'saveButton', self.save_config)
        self.bind('recipes', 'cancelButton', lambda: self.show('home'))
        self.bind('recipes', 'runButton', self.start_run)
        self.bind('recipes', 'createNewButton', lambda: self.show('configure'))
        self.bind('run', 'StopButton', self.stop_run)
        self.bind('run', 'PauseButton', self.pause_run)
        self.bind('run', 'WrongCanPopupButton', self.wrong_can)

        self.recipe_table = self.find('recipes', 'recipeTable', QTableWidget)
        if self.recipe_table:
            self.recipe_table.itemSelectionChanged.connect(self.select_recipe)
        self.add_back_button('configure', 'Back to Home', 'home')
        self.add_back_button('recipes', 'Back to Home', 'home')
        self.add_back_button('run', 'Back to Home', 'home')
        self.update_total()
        self.populate_recipes()
        self.show('home')

    def find(self, page, name, kind=QWidget):
        return self.pages[page].findChild(kind, name)

    def bind(self, page, name, callback):
        button = self.find(page, name, QPushButton)
        if button:
            button.clicked.connect(lambda checked=False, action=callback: action())

    def add_back_button(self, page, title, destination):
        content = self.pages[page]
        button = QPushButton(title, content)
        button.setObjectName('navigationBackButton')
        button.setGeometry(625, 12, 163, 47)
        button.setStyleSheet('QPushButton {background:#526D86;color:white;border-radius:8px;font-size:14px;font-weight:bold;} QPushButton:hover {background:#6986A1;}')
        button.raise_()
        button.clicked.connect(lambda checked=False, target=destination: self.navigate_back(target))

    def navigate_back(self, destination):
        if self.current == 'run':
            self.timer.stop()
            self.running = False
        self.show(destination)

    def show(self, name):
        if name == 'history':
            self.history.load_history()
            destination = self.history
        else:
            if name == 'recipes':
                self.populate_recipes()
            if name == 'run':
                self.update_target()
            destination = self.views[name]
        self.current = name
        self.stack.setCurrentWidget(destination)
        if not self.window.isVisible():
            self.window.showFullScreen()

    def adjust(self, color, delta):
        label = self.find('configure', f'{color}QtyLabel', QLabel)
        if label:
            label.setText(str(max(0, int(label.text()) + delta)))
        self.update_total()

    def get_config(self):
        config = {}
        for color in ('red', 'green', 'blue'):
            label = self.find('configure', f'{color}QtyLabel', QLabel)
            enabled = self.find('configure', f'{color}Enabled', QCheckBox)
            config[color.capitalize()] = int(label.text()) if label and (enabled is None or enabled.isChecked()) else 0
        return config

    def update_total(self, *_):
        total = sum(self.get_config().values())
        label = self.find('configure', 'totalLabel', QLabel)
        if label:
            label.setText(f'Total Expected Cans: {total}')

    def save_config(self):
        config = self.get_config()
        if sum(config.values()) == 0:
            QMessageBox.warning(self.pages['configure'], 'Invalid Configuration', 'Enable at least one can type with a positive quantity.')
            return
        self.config = config
        name_field = self.find('configure', 'recipeNameInput', QLineEdit)
        name = name_field.text().strip() if name_field else ''
        if not name:
            name = f'Custom Recipe {len(self.recipes)}'
        if name in self.recipes:
            QMessageBox.warning(self.pages['configure'], 'Duplicate Recipe', 'Please choose a unique recipe name.')
            return
        self.recipes[name] = config.copy()
        self.selected_recipe = name
        if name_field:
            name_field.clear()
        self.show('recipes')

    def populate_recipes(self):
        if not self.recipe_table:
            return
        table = self.recipe_table
        table.blockSignals(True)
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(['Recipe', 'Red', 'Green', 'Blue'])
        table.setRowCount(len(self.recipes))
        selected_row = 0
        for row, (name, config) in enumerate(self.recipes.items()):
            for col, value in enumerate([name, config['Red'], config['Green'], config['Blue']]):
                table.setItem(row, col, QTableWidgetItem(str(value)))
            if name == self.selected_recipe:
                selected_row = row
        table.selectRow(selected_row)
        table.blockSignals(False)
        self.update_recipe_labels()

    def select_recipe(self):
        row = self.recipe_table.currentRow()
        if row >= 0 and self.recipe_table.item(row, 0):
            self.selected_recipe = self.recipe_table.item(row, 0).text()
            self.update_recipe_labels()

    def update_recipe_labels(self):
        config = self.recipes[self.selected_recipe]
        label = self.find('recipes', 'selectedRecipeLabel', QLabel)
        if label:
            label.setText(f'Selected Recipe: {self.selected_recipe}')
        breakdown = self.find('recipes', 'recipeBreakdownLabel', QLabel)
        if breakdown:
            breakdown.setText(f"Red: {config['Red']}  Green: {config['Green']}  Blue: {config['Blue']}")

    def update_target(self):
        label = self.find('run', 'TargetQuantityLabel', QLabel)
        if label:
            label.setText(f'Target Quantity: {sum(self.config.values())}')

    def start_run(self):
        self.config = self.recipes[self.selected_recipe].copy()
        self.elapsed = 0
        self.running = True
        self.show('run')
        self.timer.start(1000)
        self.set_run_status('STATUS: RUNNING', 'PAUSE')

    def tick(self):
        self.elapsed += 1
        h, remainder = divmod(self.elapsed, 3600)
        m, s = divmod(remainder, 60)
        label = self.find('run', 'RunTimerLabel', QLabel)
        if label:
            label.setText(f'Run Time: {h:02}:{m:02}:{s:02}')

    def set_run_status(self, status_text, button_text):
        status = self.find('run', 'StatusLabel', QLabel)
        if status:
            status.setText(status_text)
        button = self.find('run', 'PauseButton', QPushButton)
        if button:
            button.setText(button_text)

    def pause_run(self):
        self.running = not self.running
        if self.running:
            self.timer.start(1000)
            self.set_run_status('STATUS: RUNNING', 'PAUSE')
        else:
            self.timer.stop()
            self.set_run_status('STATUS: PAUSED', 'RESUME')

    def stop_run(self):
        self.timer.stop()
        self.running = False
        self.elapsed = 0
        self.set_run_status('STATUS: STOPPED', 'START')
        self.show('home')

    def wrong_can(self):
        QMessageBox.warning(self.pages['run'], 'Inspection Alert',
                            'Manual wrong-can demonstration only. Camera inspection is not connected.')

if __name__ == '__main__':
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    hmi = HMI()
    sys.exit(app.exec())
