"""Qt worker: live ELP USB camera + team's Yards Pipeline (no demos)."""
import sys
import threading
import time

import cv2
from PySide6.QtCore import QThread, Signal

from vision_bridge import VisionEngine


class CameraWorker(QThread):
    # The worker NEVER touches Qt widgets. Frame and metadata go to the GUI thread.
    frame_ready = Signal(object, object, object, object)
    camera_error = Signal(str)
    detection_error = Signal(str)

    def __init__(self, settings, source=0, vision_root=None, backend='auto', model=None, parent=None):
        super().__init__(parent)
        self.settings = settings
        self.source = source
        self.vision_root = vision_root
        self.backend = backend
        self.model = model
        self._lock = threading.Lock()
        self._keep_running = True
        self._active = True
        self._reset_requested = False

    def set_active(self, active):
        with self._lock:
            self._active = bool(active)

    def reset_box(self):
        with self._lock:
            self._reset_requested = True

    def stop(self):
        with self._lock:
            self._keep_running = False
        if self.isRunning():
            self.wait(10000)

    def _open_camera(self):
        source = int(self.source) if isinstance(self.source, str) and self.source.isdecimal() else self.source
        if not isinstance(source, int) or source < 0:
            raise RuntimeError('Use a live USB camera number such as --camera 0 or --camera 1. '
                               'Video files and demo sources are not supported.')
        width = int(self.settings.get('frame_width', 1280))
        height = int(self.settings.get('frame_height', 720))
        fps = float(self.settings.get('camera_fps', 30))
        # Prefer the team's tuned ELP USB camera configuration if available.
        try:
            from pathlib import Path
            vision_root = Path(self.vision_root) if self.vision_root else Path(__file__).resolve().parent / 'vision'
            if (vision_root / 'yardspi' / 'camera.py').is_file():
                if str(vision_root) not in sys.path:
                    sys.path.insert(0, str(vision_root))
                from yardspi.camera import open_camera
                cap, _camera_info = open_camera(str(source), width, height, 'MJPG', fps)
                if cap is not None and cap.isOpened():
                    return cap
                if cap is not None:
                    cap.release()
        except (ImportError, OSError, RuntimeError, ValueError):
            # Still allow raw camera preview when the team's module is missing.
            pass
        backends = [cv2.CAP_V4L2, cv2.CAP_ANY] if sys.platform.startswith('linux') else [cv2.CAP_ANY]
        for capture_backend in backends:
            cap = cv2.VideoCapture(source, capture_backend)
            if not cap.isOpened():
                cap.release()
                continue
            cap.set(cv2.CAP_PROP_FOURCC, cv2.VideoWriter_fourcc(*'MJPG'))
            cap.set(cv2.CAP_PROP_FRAME_WIDTH, width)
            cap.set(cv2.CAP_PROP_FRAME_HEIGHT, height)
            cap.set(cv2.CAP_PROP_FPS, fps)
            cap.set(cv2.CAP_PROP_BUFFERSIZE, 1)
            ok, first = cap.read()
            if ok and first is not None:
                return cap
            cap.release()
        raise RuntimeError('USB ELP camera did not return frames. Check USB cable, camera number '
                           'and /dev/video* device; try --camera 1.')

    def run(self):
        cap = None
        engine = VisionEngine(self.vision_root or __import__('pathlib').Path(__file__).resolve().parent / 'vision',
                              backend=self.backend, model=self.model)
        vision_error = ''
        last_counts = {'Red': 0, 'Green': 0, 'Blue': 0}
        last_metadata = {'ready': False, 'error': 'Loading model'}
        started = time.perf_counter()
        last_preview = 0.0
        try:
            cap = self._open_camera()
            try:
                engine.start()
            except Exception as exc:
                vision_error = str(exc)
                self.detection_error.emit(vision_error)
            while True:
                with self._lock:
                    if not self._keep_running:
                        break
                    active = self._active
                    reset = self._reset_requested
                    self._reset_requested = False
                ok, frame = cap.read()
                if not ok or frame is None:
                    raise RuntimeError('USB camera stopped returning images. Check cable and power.')
                now = time.perf_counter() - started
                if reset:
                    last_counts = {'Red': 0, 'Green': 0, 'Blue': 0}
                    if engine.pipeline is not None:
                        try:
                            engine.new_box(now)
                        except Exception as exc:
                            vision_error = 'Failed to reset pipeline: ' + str(exc)
                            self.detection_error.emit(vision_error)
                            engine.close()
                if engine.pipeline is not None and active:
                    try:
                        overlay, events, last_counts, last_metadata = engine.process(frame, now)
                    except Exception as exc:
                        vision_error = 'Vision pipeline stopped: ' + str(exc)
                        self.detection_error.emit(vision_error)
                        engine.close()
                        last_counts = {'Red': 0, 'Green': 0, 'Blue': 0}
                        last_metadata = {'ready': False, 'error': vision_error}
                        overlay, events = frame.copy(), []
                else:
                    overlay, events = frame.copy(), []
                    if engine.pipeline is None:
                        last_metadata = {'ready': False, 'error': vision_error or 'Team vision model is unavailable'}
                    else:
                        last_metadata = dict(last_metadata, paused=True)
                if engine.pipeline is None:
                    cv2.rectangle(overlay, (0, 0), (overlay.shape[1], 40), (25, 35, 110), -1)
                    cv2.putText(overlay, 'LIVE CAMERA - MODEL NOT CONFIGURED', (12, 28),
                                cv2.FONT_HERSHEY_SIMPLEX, .7, (255, 255, 255), 2)
                elif not active:
                    cv2.putText(overlay, 'PAUSED - NOT COUNTING', (12, 65),
                                cv2.FONT_HERSHEY_SIMPLEX, .7, (0, 220, 255), 2)
                # Analyze all frames; display a maximum of ~10 frames/sec on the HMI.
                if time.perf_counter() - last_preview >= 0.10:
                    self.frame_ready.emit(overlay, events, last_counts.copy(), dict(last_metadata))
                    last_preview = time.perf_counter()
        except Exception as exc:
            self.camera_error.emit(str(exc))
        finally:
            engine.close()
            if cap is not None:
                cap.release()
