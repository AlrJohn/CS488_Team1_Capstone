# Yards Brewing Can Inspection HMI — Team Vision Pipeline Integration

This edition **replaces the experimental HSV placement tracker** with an adapter
for the team's actual `yardspi.pipeline.Pipeline`, `OnnxBackend` / `HailoBackend`,
and ELP USB camera capture, using the `vision/pi/run.py` code supplied by the
team. The Home, Configure Batch, Recipe Selection, Production Run and Inspection
History Qt screens remain in the application. **There is no demo video, fake
can simulation, or virtual counting line.**

## IMPORTANT: Additional team files are still required

The supplied text contains **only `vision/pi/run.py`**. It imports modules and
models that were not in the supplied ZIP. To run trained detection, copy the
following **actual files from your team's repository** into the included
`vision/` folder (do not invent empty replacements):

```text
FinalizedCanDetectionUISystem_Yards_Vision_Integrated/
├── main.py
├── camera_worker.py
├── vision_bridge.py
├── station_settings.json
└── vision/
    ├── pi/
    │   └── run.py                   # the exact code you supplied (for reference)
    ├── yardspi/
    │   ├── __init__.py
    │   ├── pipeline.py              # REQUIRED
    │   ├── backends.py              # REQUIRED
    │   ├── camera.py                # REQUIRED for the team's camera setup
    │   └── ...                     # other imported team modules
    ├── configs/
    │   ├── runtime.json            # REQUIRED, including model_sha256 and inference
    │   ├── colors.json             # REQUIRED
    │   └── view.json               # REQUIRED
    └── models/
        ├── can-camera-v1.hef        # Hailo model, OR .onnx for CPU backend
        └── can-camera-v1.hef.json   # matching identity JSON, OR .onnx.json
```

Other files imported by the team's `yardspi` package, such as `common` helpers,
may also be necessary. Keep the whole original `vision/` folder if possible.
The HMI uses `Pipeline.process()` directly inside a Qt worker, not the original
`run.py` command-line window. The original file is preserved for reference.
The original `run.py` also imports `stack_lights`, which is not in the provided
files; it is not needed for the Qt HMI adapter.

If the model or configs are missing, **the USB camera still opens and shows live
video**, but the HMI displays **MODEL NOT READY**, disables **FINISH BOX**, and
does **not** make up counts or record PASS. This is intentional.

## Raspberry Pi 5 + Acer monitor + USB ELP camera

1. Connect the ELP USB camera directly to the Raspberry Pi. The Acer is the
   monitor and does not need Windows software.
2. Open the Raspberry Pi's Terminal and install the GUI and camera packages:

```bash
sudo apt update
sudo apt install -y python3-pyside6.qtcore python3-pyside6.qtgui python3-pyside6.qtwidgets python3-pyside6.qtuitools python3-opencv python3-numpy v4l-utils unzip
```

3. Download the ZIP to the Raspberry Pi's **Downloads** folder, then extract it:

```bash
cd ~/Downloads
unzip -o FinalizedCanDetectionUISystem_Yards_Vision_Integrated.zip
cd FinalizedCanDetectionUISystem_Yards_Vision_Integrated
```

4. Copy the missing team's `yardspi`, `configs`, `models` and any supporting
   folders into the **vision/** folder before attempting trained detection.
5. Check the camera and which vision files are present:

```bash
v4l2-ctl --list-devices
python3 check_setup.py --camera 0
```

6. Start the full-screen HMI:

```bash
python3 main.py --camera 0 --backend auto
```

If camera 0 isn't the ELP camera, use `--camera 1` or the actual V4L2 index.
If you know you have a Hailo-8 HAT and its `.hef` model, use `--backend hailo`.
If your team uses the ONNX model and has installed its inference dependencies,
use `--backend onnx`. **A `.hef` requires compatible Hailo hardware/runtime.**

The team's vision model may need additional dependencies beyond PySide6,
OpenCV, and NumPy. Install them according to your team's repository and Pi
image. A camera test succeeding does not mean the model is installed.

## How Production Run works

- Press **Production Run**: Qt opens the **live USB ELP camera** (no other video).
- `CameraWorker` calls the team's `Pipeline.process(frame, seconds)` on each
  live frame and sends the real returned `pack.counts`, `pack.status`,
  `pack.recipe`, tracked objects and ROI to the GUI.
- The camera preview draws the team's tracked masks and ROI rectangle; the
  magenta `defect_x` line from the standalone script is **not drawn**.
- The displayed recipe must agree with `row['pack']['recipe']`. If they differ,
  the HMI shows **RECIPE MISMATCH** and prevents saving. **The UI recipe does
  not automatically change the team's `runtime.json` recipe**; that needs
  the team to expose a recipe-update API or specify the runtime config format.
- **Pause** stops analysis but continues the live camera preview. **Finish
  Box** saves the pipeline's counts and asks the operator to replace the box.
- A pipeline `REVIEW`/`FAIL` state or framing warning prevents a matching count
  from being automatically recorded as PASS; it is saved as REVIEW.
- Inspection History reads `inspection_history.csv`.

### Important accuracy limitation from the supplied code

The team's own `run.py` describes its result as **"Assumed packed from V4 ROI
admission; carton placement is not verified"**. Its logic counts configured
ROI admissions, **not proof that a worker released each can into the box**.
Connecting that exact pipeline to the HMI does not change its counting logic.
The camera position, `view.json`, lighting, model, and physical workflow must
be tested with real cartons; the team may need to change the admission logic
for your manual packing station.

## Diagnostics and tests

```bash
python3 check_setup.py --camera 0
python3 -m unittest -v test_vision_bridge
```

Six automated tests cover bridge behavior, model-file checks, a simulated
**API stub** for `Pipeline.process()`, overlays and history. They do **not** run
real inference, connect to physical camera hardware, or validate real counts.
The Qt GUI also requires PySide6 on the target Raspberry Pi.

## Custom paths and settings

- `--vision-root /path/to/vision`: point to the complete team vision directory
  instead of copying it into the project.
- `--model /path/to/model.hef`: specify a nonstandard model path, with its
  matching `.json` identity file.
- `station_settings.json`: USB camera index, requested MJPG resolution and FPS.
- `vision/configs/view.json`: the team's ROI/rotation configuration.

To use a different recipe, ensure the **actual vision pipeline recipe** matches
what is selected in the HMI before accepting inspections.
