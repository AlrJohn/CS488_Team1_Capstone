"""Adapter between the team's Yards vision Pipeline and the Qt HMI.

Uses the exact Pipeline.process(frame, seconds) contract in the supplied
vision/pi/run.py. No synthetic video, HSV substitute, or OpenCV window.
The complete yardspi package, configs, and verified model must be supplied.
"""
import hashlib
import json
import sys
from pathlib import Path

import cv2
import numpy as np

COLORS = ('red', 'green', 'blue')
PALETTE = {'red': (0, 0, 255), 'green': (0, 230, 0),
           'blue': (255, 110, 40), 'unknown': (160, 160, 160)}


class VisionSetupError(RuntimeError):
    pass


def normalized_colors(value):
    if not isinstance(value, dict) or any(k not in value for k in COLORS):
        raise ValueError('Vision pipeline must return red, green, and blue counts/recipe.')
    return {name.capitalize(): int(value[name]) for name in COLORS}


def draw_vision_frame(frame, row, masks):
    """Overlay the team's instance masks and tracked boxes; NO tripwire line."""
    view = frame.copy()
    height, width = view.shape[:2]
    x, y, w, h = map(int, row.get('roi_xywh', (0, 0, width, height)))
    x = max(0, min(width - 1, x))
    y = max(0, min(height - 1, y))
    w = max(1, min(width - x, w))
    h = max(1, min(height - y, h))
    region = view[y:y+h, x:x+w]
    observations = row.get('observations', [])
    for observation, mask in zip(observations, masks if masks is not None else []):
        color = PALETTE.get(str(observation.get('color', 'unknown')).lower(), PALETTE['unknown'])
        mask = np.asarray(mask, dtype=np.uint8)
        if mask.ndim == 2 and mask.shape == (h, w):
            selected = mask.astype(bool)
            if selected.any():
                region[selected] = (region[selected].astype(np.float32) * .65 +
                                    np.asarray(color, dtype=np.float32) * .35).astype(np.uint8)
    for observation in observations:
        color_name = str(observation.get('color', 'unknown')).lower()
        color = PALETTE.get(color_name, PALETTE['unknown'])
        coords = observation.get('xyxy_roi')
        if coords is None or len(coords) != 4:
            continue
        a, b, c, d = (int(round(float(v))) for v in coords)
        cv2.rectangle(view, (x+a, y+b), (x+c, y+d), color, 2)
        cv2.putText(view, f'T{observation.get("track_id", "?")} {color_name}',
                    (x+a, max(20, y+b-7)), cv2.FONT_HERSHEY_SIMPLEX,
                    .52, color, 2, cv2.LINE_AA)
    cv2.rectangle(view, (x, y), (x+w-1, y+h-1), (0, 220, 255), 2)
    pack = row.get('pack', {})
    counts = pack.get('counts', {})
    status = str(pack.get('status', 'ANALYZING'))
    info = (f'YARDS VISION  |  R {counts.get("red", "?")}  '
            f'G {counts.get("green", "?")}  B {counts.get("blue", "?")}  |  {status}')
    cv2.rectangle(view, (0, 0), (width, 34), (18, 34, 51), -1)
    cv2.putText(view, info[:92], (10, 24), cv2.FONT_HERSHEY_SIMPLEX,
                .58, (255, 255, 255), 1, cv2.LINE_AA)
    return view


class VisionEngine:
    """Own the team's inference backend and Pipeline in the camera thread."""

    def __init__(self, vision_root, backend='auto', model=None):
        self.root = Path(vision_root).expanduser().resolve()
        self.backend_name = backend
        self.model_path = Path(model).expanduser().resolve() if model else None
        self.backend = None
        self.pipeline = None

    def start(self):
        root = self.root
        config_dir = root / 'configs'
        paths = {name: config_dir / (name + '.json') for name in ('runtime', 'colors', 'view')}
        missing = [str(path.relative_to(root)) for path in paths.values() if not path.is_file()]
        if missing:
            raise VisionSetupError('Missing team vision configuration: ' + ', '.join(missing) +
                                   '. Copy the complete vision/configs folder from your team repository.')
        try:
            config = json.loads(paths['runtime'].read_text(encoding='utf-8'))
        except (OSError, ValueError) as exc:
            raise VisionSetupError('Cannot read vision/configs/runtime.json: ' + str(exc)) from exc
        if 'inference' not in config or 'model_sha256' not in config:
            raise VisionSetupError('runtime.json must contain inference and model_sha256 from the team project.')

        model = self.model_path
        if self.backend_name == 'auto':
            if model:
                chosen = 'hailo' if model.suffix.lower() == '.hef' else 'onnx'
            elif (root / 'models' / 'can-camera-v1.hef').is_file():
                chosen = 'hailo'
            elif (root / 'models' / 'can-camera-v1.onnx').is_file():
                chosen = 'onnx'
            else:
                raise VisionSetupError('Missing trained model: copy vision/models/can-camera-v1.hef '
                                       '(Hailo) or can-camera-v1.onnx (CPU), with its matching .json identity file.')
        else:
            chosen = self.backend_name
        if chosen not in ('hailo', 'onnx'):
            raise VisionSetupError('Backend must be auto, hailo, or onnx.')
        model = model or (root / 'models' / ('can-camera-v1.hef' if chosen == 'hailo' else 'can-camera-v1.onnx'))
        if not model.is_file():
            raise VisionSetupError('Trained model is missing: ' + str(model))
        identity_path = model.with_suffix(model.suffix + '.json')
        if not identity_path.is_file():
            raise VisionSetupError('Missing model identity file: ' + str(identity_path))
        try:
            identity = json.loads(identity_path.read_text(encoding='utf-8'))
            model_sha = hashlib.sha256(model.read_bytes()).hexdigest()
        except (OSError, ValueError) as exc:
            raise VisionSetupError('Cannot verify model identity: ' + str(exc)) from exc
        if identity.get('sha256') != model_sha:
            raise VisionSetupError('Model hash does not match the identity file. Use the team-provided model and JSON together.')
        if identity.get('source_sha256', identity.get('source_checkpoint_sha256')) != config['model_sha256']:
            raise VisionSetupError('Model was built from a different checkpoint than runtime.json expects.')
        if not (root / 'yardspi' / 'pipeline.py').is_file():
            raise VisionSetupError('Missing vision/yardspi/pipeline.py. The pasted run.py imports this; '
                                   'copy the complete vision/yardspi package from your team repository.')
        if str(root) not in sys.path:
            sys.path.insert(0, str(root))
        try:
            from yardspi.backends import OnnxBackend, HailoBackend
            from yardspi.pipeline import Pipeline
        except (ImportError, OSError) as exc:
            raise VisionSetupError('Cannot import team vision modules: ' + str(exc)) from exc
        try:
            self.backend = (HailoBackend if chosen == 'hailo' else OnnxBackend)(model, config['inference'])
            self.pipeline = Pipeline(root, self.backend, view=paths['view'],
                                     runtime=paths['runtime'], colors=paths['colors'])
        except Exception as exc:
            self.close()
            raise VisionSetupError(f'Cannot initialize {chosen} model/Pipeline: {exc}') from exc
        self.backend_name = chosen

    def process(self, frame, now):
        row, masks = self.pipeline.process(frame, now)
        if not isinstance(row, dict) or not isinstance(row.get('pack'), dict):
            raise RuntimeError('Pipeline.process() did not return a row containing pack data.')
        pack = row['pack']
        counts = normalized_colors(pack.get('counts'))
        recipe = normalized_colors(pack.get('recipe'))
        overlay = draw_vision_frame(frame, row, masks)
        return overlay, list(row.get('transfer_events', [])), counts, {
            'ready': True,
            'backend': self.backend_name,
            'recipe': recipe,
            'status': str(pack.get('status', 'ANALYZING')),
            'framing_warning': str(row.get('framing_warning') or ''),
            'box': pack.get('box'),
            'total': int(pack.get('total', sum(counts.values()))),
        }

    def new_box(self, now):
        if self.pipeline is not None:
            self.pipeline.new_box(now)

    def close(self):
        backend, self.backend = self.backend, None
        self.pipeline = None
        if backend is not None:
            backend.close()
