# Team vision dependencies not included

The supplied run.py is preserved at pi/run.py. It imports `yardspi.backends`,
`yardspi.pipeline`, `yardspi.camera`, `stack_lights`, and may require other
team code. None of these modules, the model weights, or JSON configurations
were supplied with this message. Copy the complete `vision/` folder from your
team repository into this directory. Do not use empty placeholder models or
configs; the adapter checks model SHA-256 identity before counting.

When these are missing, the HMI displays the real USB camera but **does not
count cans**. See the parent README for installation and tests.
