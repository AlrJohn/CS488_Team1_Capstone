"""Check Raspberry Pi USB camera and required team vision files before HMI use."""
import argparse
import importlib.util
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent


def check_files(root):
    root = Path(root)
    required = [
        'yardspi/pipeline.py', 'yardspi/backends.py', 'yardspi/camera.py',
        'configs/runtime.json', 'configs/colors.json', 'configs/view.json',
    ]
    for name in required:
        path = root / name
        print(('OK     ' if path.is_file() else 'MISSING') + '  vision/' + name)
    model_candidates = [root/'models/can-camera-v1.hef', root/'models/can-camera-v1.onnx']
    for model in model_candidates:
        if model.is_file():
            print('OK       vision/models/' + model.name)
            identity = model.with_suffix(model.suffix + '.json')
            print(('OK     ' if identity.is_file() else 'MISSING') + '  vision/models/' + identity.name)
    if not any(p.is_file() for p in model_candidates):
        print('MISSING  vision/models/can-camera-v1.hef or can-camera-v1.onnx')
    return all((root/p).is_file() for p in required) and any(
        p.is_file() and p.with_suffix(p.suffix+'.json').is_file() for p in model_candidates)


def check_camera(source):
    try:
        import cv2
    except ImportError as exc:
        print('OpenCV import failed:', exc)
        return False
    cap = cv2.VideoCapture(source, cv2.CAP_V4L2)
    if not cap.isOpened():
        cap.release()
        cap = cv2.VideoCapture(source)
    ok, frame = cap.read() if cap.isOpened() else (False, None)
    cap.release()
    print('USB ELP camera:', 'OK' if ok and frame is not None else 'NOT AVAILABLE')
    if frame is not None:
        print('Camera frame dimensions:', frame.shape[1], 'x', frame.shape[0])
    return bool(ok and frame is not None)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--vision-root', type=Path, default=BASE/'vision')
    parser.add_argument('--camera', type=int, default=0)
    parser.add_argument('--skip-camera', action='store_true')
    args = parser.parse_args()
    print('=== Python modules ===')
    for name in ('cv2', 'numpy', 'PySide6'):
        try:
            installed = importlib.util.find_spec(name) is not None
        except (ImportError, ValueError):
            installed = False
        print(('OK     ' if installed else 'MISSING') + '  ' + name)
    print('\n=== Team vision files ===')
    files_ok = check_files(args.vision_root)
    if not args.skip_camera:
        print('\n=== USB camera ===')
        camera_ok = check_camera(args.camera)
    else:
        camera_ok = True
    print('\nSummary:', 'READY FOR MODEL INITIALIZATION' if files_ok and camera_ok else
          'NOT FULLY READY — see MISSING/NOT AVAILABLE above')
    print('This check does not verify trained model inference or physical can counts.')


if __name__ == '__main__':
    main()
