"""Tests for the supplied run.py -> Qt bridge (no physical Pi hardware)."""
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

import cv2
import numpy as np
from vision_bridge import VisionEngine, VisionSetupError, normalized_colors, draw_vision_frame
from history_store import save_box


class VisionBridgeTests(unittest.TestCase):
    def test_missing_team_config_gives_actionable_error(self):
        with tempfile.TemporaryDirectory() as directory:
            engine = VisionEngine(directory)
            with self.assertRaisesRegex(VisionSetupError, 'Missing team vision configuration'):
                engine.start()

    def test_missing_model_gives_actionable_error(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'configs').mkdir()
            for name in ('runtime', 'colors', 'view'):
                (root/'configs'/f'{name}.json').write_text(json.dumps(
                    {'model_sha256': 'abc', 'inference': {}} if name == 'runtime' else {}))
            with self.assertRaisesRegex(VisionSetupError, 'Missing trained model'):
                VisionEngine(root).start()

    def test_invalid_model_identity_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'configs').mkdir()
            (root/'models').mkdir()
            for name in ('runtime', 'colors', 'view'):
                (root/'configs'/f'{name}.json').write_text(json.dumps(
                    {'model_sha256': 'abc', 'inference': {}} if name == 'runtime' else {}))
            model = root/'models'/'can-camera-v1.hef'
            model.write_bytes(b'dummy')
            (root/'models'/'can-camera-v1.hef.json').write_text(json.dumps(
                {'sha256': 'not-the-correct-hash', 'source_sha256': 'abc'}))
            with self.assertRaisesRegex(VisionSetupError, 'Model hash does not match'):
                VisionEngine(root, backend='hailo').start()

    def test_normalized_colors(self):
        self.assertEqual(normalized_colors({'red': 2, 'green': 3, 'blue': 4}),
                         {'Red': 2, 'Green': 3, 'Blue': 4})
        with self.assertRaises(ValueError):
            normalized_colors({'red': 1})

    def test_draws_roi_and_tracks_without_virtual_line(self):
        frame = np.zeros((120, 160, 3), dtype=np.uint8)
        row = {'roi_xywh': [10, 10, 120, 90],
               'observations': [{'color': 'red', 'track_id': 7, 'xyxy_roi': [10, 10, 40, 50]}],
               'pack': {'counts': {'red': 1, 'green': 0, 'blue': 0}, 'status': 'COUNTING'}}
        mask = np.zeros((90, 120), dtype=np.uint8)
        mask[10:50, 10:40] = 1
        overlay = draw_vision_frame(frame, row, [mask])
        self.assertEqual(overlay.shape, frame.shape)
        self.assertTrue(np.any(overlay != frame))

    def test_history_csv_still_works(self):
        with tempfile.TemporaryDirectory() as directory:
            config = {'Red': 4, 'Green': 4, 'Blue': 4}
            record = save_box(Path(directory)/'history.csv', 'Standard', config, config,
                              mode='YARDS-PIPELINE-PROVISIONAL')
            self.assertEqual(record['Status'], 'PASS')
            self.assertEqual(record['Mode'], 'YARDS-PIPELINE-PROVISIONAL')

    def test_bridge_with_fake_team_pipeline(self):
        # A stand-in tests the API integration; this is NOT a real model test.
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            (root/'configs').mkdir()
            (root/'models').mkdir()
            (root/'yardspi').mkdir()
            (root/'yardspi'/'__init__.py').write_text('')
            (root/'yardspi'/'backends.py').write_text('''
class OnnxBackend:
    def __init__(self, model, inference): self.closed = False
    def close(self): self.closed = True
class HailoBackend(OnnxBackend): pass
''')
            (root/'yardspi'/'pipeline.py').write_text('''
import numpy as np
class Pipeline:
    def __init__(self, root, backend, view, runtime, colors):
        self.reset_count = 0
    def process(self, frame, now):
        return ({'roi_xywh': (0, 0, frame.shape[1], frame.shape[0]),
                 'observations': [{'color':'red','track_id':1,'xyxy_roi':(10,10,30,30)}],
                 'transfer_events':[{'type':'entry'}],
                 'pack': {'counts':{'red':1,'green':0,'blue':0},
                          'recipe':{'red':4,'green':4,'blue':4},
                          'status':'COUNTING','box':1,'total':1}},
                [np.zeros(frame.shape[:2],dtype=np.uint8)])
    def new_box(self, now): self.reset_count += 1
''')
            data = b'not-a-real-model'
            model = root/'models'/'can-camera-v1.onnx'
            model.write_bytes(data)
            digest = hashlib.sha256(data).hexdigest()
            (root/'models'/'can-camera-v1.onnx.json').write_text(json.dumps(
                {'sha256': digest, 'source_sha256': 'checkpoint'}))
            (root/'configs'/'runtime.json').write_text(json.dumps(
                {'model_sha256': 'checkpoint', 'inference': {}}))
            (root/'configs'/'colors.json').write_text('{}')
            (root/'configs'/'view.json').write_text('{}')
            for name in list(sys.modules):
                if name == 'yardspi' or name.startswith('yardspi.'):
                    del sys.modules[name]
            engine = VisionEngine(root, backend='onnx')
            try:
                engine.start()
                overlay, events, counts, meta = engine.process(
                    np.zeros((100, 120, 3), dtype=np.uint8), 0.5)
                self.assertEqual(overlay.shape, (100, 120, 3))
                self.assertEqual(counts, {'Red': 1, 'Green': 0, 'Blue': 0})
                self.assertEqual(meta['recipe'], {'Red': 4, 'Green': 4, 'Blue': 4})
                self.assertTrue(meta['ready'])
                self.assertEqual(len(events), 1)
                engine.new_box(0.6)
                self.assertEqual(engine.pipeline.reset_count, 1)
            finally:
                engine.close()
                for name in list(sys.modules):
                    if name == 'yardspi' or name.startswith('yardspi.'):
                        del sys.modules[name]
                if str(root) in sys.path:
                    sys.path.remove(str(root))


if __name__ == '__main__':
    unittest.main()
